<?php

// Rent Day min
woocommerce_wp_text_input(
  array(
   'id'                => 'ovabrw_rent_day_min',
   'class'             => 'short ',
   'label'             => esc_html__( 'Min Rental Dates', 'ova-brw' ),
   'placeholder'       => esc_html__( '0.5', 'ova-brw' ),
   'desc_tip'    => 'true',
   'type'              => 'text'
));

// Rent Hour min
woocommerce_wp_text_input(
  array(
   'id'                => 'ovabrw_rent_hour_min',
   'class'             => 'short ',
   'label'             => esc_html__( 'Min Rental Hours', 'ova-brw' ),
   'placeholder'       => esc_html__( '1', 'ova-brw' ),
   'desc_tip'    => 'true',
   'type'              => 'text'
));