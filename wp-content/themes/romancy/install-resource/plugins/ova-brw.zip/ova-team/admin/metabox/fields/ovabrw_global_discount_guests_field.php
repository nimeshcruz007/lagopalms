<tr class="tr_ovabrw_discount_guests">
    <td width="11%">
        <input 
            type="text" 
            class="input_text" 
            placeholder="<?php esc_html_e('10.5', 'ova-brw'); ?>" 
            name="ovabrw_discount_guests_price[]" />
    </td>
    <td width="13%">
        <input 
            type="text" 
            class="input_text ovabrw_discount_guests_duration" 
            placeholder="<?php esc_html_e('1', 'ova-brw'); ?>" 
            name="ovabrw_discount_guests_duration_min[]" />
        <input 
            type="text" 
            class="input_text ovabrw_discount_guests_duration" 
            placeholder="<?php esc_html_e('2', 'ova-brw'); ?>" 
            name="ovabrw_discount_guests_duration_max[]" />
        <select class="ovabrw_discount_guests_type ovabrw_discount_guests_duration" name="ovabrw_discount_guests_type[]">
            <option value="guests" selected><?php esc_html_e('/Guests', 'ova-brw'); ?></option>
        </select>
    </td>
    <td width="1%"><a href="#" class="delete_discount_guests">x</a></td>
</tr>