<div class="ovabrw_discount_guests">
	<table class="widefat">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Price', 'ova-brw' ); ?></th>
				<th><?php esc_html_e( 'Duration (Min - Max): Number', 'ova-brw' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<!-- Append html here -->
			<?php if ( $discount_guests_price = get_post_meta( $post_id, 'ovabrw_discount_guests_price', 'false' ) ) {
				$discount_guests_duration_min = get_post_meta( $post_id, 'ovabrw_discount_guests_duration_min', 'false' );
				$discount_guests_duration_max = get_post_meta( $post_id, 'ovabrw_discount_guests_duration_max', 'false' );

				for( $i = 0 ; $i < count( $discount_guests_price ); $i++ ) { 
					$duration_min = isset( $discount_guests_duration_min[$i] ) && $discount_guests_duration_min[$i] ? absint( $discount_guests_duration_min[$i] ) : 0;
					$duration_max = isset( $discount_guests_duration_max[$i] ) && $discount_guests_duration_max[$i] ? absint( $discount_guests_duration_max[$i] ) : 0;
				?>
					<tr class="tr_ovabrw_discount_guests">
					    <td width="11%">
					        <input 
					        	type="text" 
					        	class="input_text" 
					        	placeholder="<?php esc_html_e('10.5', 'ova-brw'); ?>" 
					            name="ovabrw_discount_guests_price[]" 
					            value="<?php esc_html_e( $discount_guests_price[$i] ); ?>" />
					    </td>
					    <td width="13%">
						    <input 
						    	type="text" 
						    	class="input_text ovabrw_discount_guests_duration" 
						    	placeholder="<?php esc_html_e('1', 'ova-brw'); ?>" 
						        name="ovabrw_discount_guests_duration_min[]" 
						        value="<?php esc_html_e( $duration_min ); ?>" />
						    <input 
						    	type="text" 
						    	class="input_text ovabrw_discount_guests_duration" 
						    	placeholder="<?php esc_html_e('2', 'ova-brw'); ?>" 
						        name="ovabrw_discount_guests_duration_max[]" 
						        value="<?php esc_html_e( $duration_max ); ?>" />
						    <select class="ovabrw_discount_guests_duration ovabrw_discount_guests_type" name="ovabrw_discount_guests_type[]">
								<option value="guests" selected><?php esc_html_e('/Guests', 'ova-brw'); ?></option>
						    </select>
					    </td>
					    <td width="1%"><a href="#" class="delete_discount_guests">x</a></td>
					</tr>
				<?php }
			} ?>
		</tbody>
		<tfoot>
			<tr>
				<th colspan="6">
					<a href="#" class="button insert_discount_guests" data-row="
						<?php
							ob_start();
							include( OVABRW_PLUGIN_PATH.'/admin/metabox/fields/ovabrw_global_discount_guests_field.php' );
							echo esc_attr( ob_get_clean() );
						?>
					">
					<?php esc_html_e( 'Add Discount', 'ova-brw' ); ?></a>
					</a>
				</th>
			</tr>
		</tfoot>
	</table>
</div>