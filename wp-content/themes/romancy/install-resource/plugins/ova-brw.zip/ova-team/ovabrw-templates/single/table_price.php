<?php 
/**
 * The template for displaying table price content within single
 *
 * This template can be overridden by copying it to yourtheme/ovabrw-templates/single/table_price.php
 *
 */

if ( ! defined( 'ABSPATH' ) ) exit();

// Get id
if( !is_product() && isset( $args['id'] ) && $args['id'] ){
	$pid = $args['id'];
}else{
	$pid = get_the_id();
}

// Check product type: rental
$product = wc_get_product( $pid );
if ( $product->get_type() !== 'ovabrw_car_rental' ) return;


$price_type   = get_post_meta( $pid, 'ovabrw_price_type', true );
$price_define = get_post_meta( $pid, 'ovabrw_define_1_day', true );

?>
<?php if( ovabrw_get_setting( get_option( 'ova_brw_template_show_table_price', 'yes' ) ) === 'yes' ){ ?>
	<div class="product_table_price">

		<!-- Daily Rent -->
		<?php if( $price_type == 'day' && $price_define == 'hotel' ){ ?>

			<div class="ovacrs_price_rent ovacrs_daily_rent">

				
				<h3 class="ovabrw-according" >
					<?php esc_html_e( 'Price', 'ova-brw' ); ?>
				</h3>

				<!-- Regular Price Hour -->
				<div class="ovabrw_collapse_content">
					

					<?php  do_action( 'ovabrw_table_price_weekdays', $pid ); ?>
					
					<?php do_action( 'ovabrw_table_price_global_discount_day', $pid ); ?>

					<?php do_action( 'ovabrw_table_price_seasons_day', $pid ); ?>

					
				</div>
				
				
			</div>

		<?php } ?>
		
		
	</div>
<?php } ?>
