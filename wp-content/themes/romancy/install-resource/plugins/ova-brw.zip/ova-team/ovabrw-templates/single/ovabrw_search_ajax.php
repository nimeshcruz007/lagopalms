<?php if( ! defined( 'ABSPATH' ) ) exit();

extract( $args );

$template   	  = $args['template'];
$posts_per_page   = $args['posts_per_page'];
$order   		  = $args['order'];
$orderby   		  = $args['orderby'];
$args['method']   = 'POST';

?>


<div class="ovabrw-search-ajax">
	<div class="wrap-search-ajax wrap-search-ajax-<?php echo esc_attr( $template ); ?>" data-template="<?php echo esc_attr( $template ) ;?>">
		
		<!-- Search -->
		<?php ovabrw_get_template('single/ovabrw_search.php', $args) ; ?>

		<!-- Load more -->
		<div class="wrap-load-more" style="display: none;">
			<svg class="loader" width="50" height="50">
				<circle cx="25" cy="25" r="10" />
				<circle cx="25" cy="25" r="20" />
			</svg>
		</div>

		<!-- Search result -->
		<div 
			id="search-ajax-result" 
			class="search-ajax-result" 
			data-order="<?php echo esc_attr( $order ); ?>" 
			data-orderby="<?php echo esc_attr( $orderby ); ?>" 
			data-posts-per-page="<?php echo esc_attr( $posts_per_page ); ?>">
		</div>

		<!-- Video -->
		<div class="modal-container">
			<div class="modal">
				<div class="modal-close">
					<i class="ovaicon-cancel"></i>
				</div>
				<iframe class="modal-video" allow="autoplay"></iframe>
			</div>
		</div>

</div>