<?php
if ( ! defined( 'ABSPATH' ) ) exit();

$id 		         = get_the_id();
$product 	         = wc_get_product( $id );
$gallery_ids	     = $product->get_gallery_image_ids();
$number_gallery      = count( $gallery_ids );

$gallery_src = array();

foreach( $gallery_ids as $k => $gallery_id ) {
	$gallery_url = wp_get_attachment_url( $gallery_id );
	$gallery_alt = get_post_meta( $gallery_id, '_wp_attachment_image_alt', true );

	if ( ! $gallery_alt ) {
		$gallery_alt = get_the_title( $gallery_id );
	}

	$src = array(
		'src' => $gallery_url,
		'caption' => $gallery_alt,
		'thumb' => $gallery_url,
	);

    array_push( $gallery_src, $src );
}

$title 		= get_the_title();
$check_in 	= $args['start_date'];
$check_out 	= $args['end_date'];
$adults 	= $args['adults'];
$childrens 	= $args['childrens'];

$date_format = ovabrw_get_date_format();
$time_format = ovabrw_get_time_format_php();

$rental_type = get_post_meta( $id, 'ovabrw_price_type', true );
$defined_one_day = defined_one_day( $id );

$date_time_format = $date_format . ' ' . $time_format;
if ( $rental_type == 'period_time' || $defined_one_day ==  'hotel' ) {
	$date_time_format = $date_format;
}

if ( $check_in ) {
	$check_in 	= date( $date_time_format, strtotime( $check_in ) );
}
if ( $check_out ) {
	$check_out 	= date( $date_time_format, strtotime( $check_out ) );
}

$link = add_query_arg( array(
	    'pickup_date' 		=> $check_in,
	    'dropoff_date' 		=> $check_out,
	    'ovabrw_adults' 	=> $adults,
	    'ovabrw_childrens' 	=> $childrens
	), get_permalink( $id ) );

$image_url 	= get_the_post_thumbnail_url( $id, 'romancy_product_thumbnail' );
$image_id 	= get_post_thumbnail_id();
$image_alt 	= '';

if ( $image_id ) {
	$image_alt 		= get_post_meta( $image_id, '_wp_attachment_image_alt', true );
	if ( empty( $image_alt ) ) {
		$image_alt = get_the_title( $image_id );
	}
}

$video_link        = get_post_meta( $id, 'ovabrw_video_link', true );
$children_number   = get_post_meta( $id, 'ovabrw_children_number', true );
$adult_number      = get_post_meta( $id, 'ovabrw_adult_number', true );
$price             = get_post_meta( $id, '_regular_price', true );
$bed_number        = get_post_meta( $id, 'ovabrw_bed_number', true );
$bath_number       = get_post_meta( $id, 'ovabrw_bath_number', true );
$area_number       = get_post_meta( $id, 'ovabrw_acreage_number', true );
$area_unit         = get_post_meta( $id, 'ovabrw_acreage_unit', true );
$parking           = get_post_meta( $id, 'ovabrw_parking', true );

$short_description = wp_trim_words( get_the_excerpt( $id ), 19, '..' );

?>

<div class="ovabrw-room-content ovabrw-room-content2">

	<div class="wrapper-room">
		
		<div class="room-img">  
			<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
            
            <?php if( !empty( $gallery_src ) || !empty( $video_link ) ) : ?>
				<div class="room-video-gallery-wrapper">

					<?php if( !empty( $video_link ) ) : ?>
						<div class="room-video-gallery room-video-link" data-src="<?php echo esc_attr( $video_link ); ?>">
							<i aria-hidden="true" class="icomoon icomoon-play"></i>
							<span class="text">
								<?php echo esc_html__('Watch video','ova-brw'); ?>
							</span>
						</div>
					<?php endif; ?>
                    
                    <?php if( !empty( $gallery_src ) ) : ?>
						<div class="room-video-gallery room-image-gallery fancybox" data-gallery-src="<?php echo esc_attr( json_encode( $gallery_src ) );?>">
							<i aria-hidden="true" class="icomoon icomoon-image-gallery"></i>
							<span class="text">
								<?php echo esc_html( $number_gallery ) . ' ' . esc_html__('Photos','ova-brw'); ?>
							</span>
						</div>
					<?php endif; ?>
		        </div>
		    <?php endif; ?>

		</div>

		<div class="room-container">

			<h2 class="room-title">
				<?php echo esc_html( $title ); ?>
			</h2>

			<ul class="room-info">
				<?php if( !empty($adult_number) ) : ?>
					<li>
						<i aria-hidden="true" class="icomoon icomoon-man"></i>
						<span>
						    <?php echo esc_html( $adult_number ) . ' ' . esc_html__('Adults','ova-brw');?>	
						</span>
					</li>
				<?php endif; ?>
				<?php if( !empty($children_number) ) : ?>
					<li>
						<i aria-hidden="true" class="icomoon icomoon-daughter"></i>
						<span>
						    <?php echo esc_html( $children_number ) . ' ' . esc_html__('Childrens','ova-brw');?>	
						</span>
					</li>
				<?php endif; ?>
				<?php if( !empty($area_number) ) : ?>
					<li>
						<i aria-hidden="true" class="icomoon icomoon-measure"></i>
						<span>
						    <?php echo esc_html( $area_number ) . ' ' . esc_html( $area_unit ); ?>	
						</span>
					</li>
				<?php endif; ?>
				<?php if( !empty($bed_number) ) : ?>
					<li>
						<i aria-hidden="true" class="icomoon icomoon-bed"></i>
						<span>
						    <?php echo esc_html( $bed_number ) . ' ' . esc_html__('Beds','ova-brw'); ?>	
						</span>
					</li>
				<?php endif; ?>
				<?php if( !empty($bath_number) ) : ?>
					<li>
						<i aria-hidden="true" class="icomoon icomoon-bathtub"></i>
						<span>
						    <?php echo esc_html( $bath_number ) . ' ' . esc_html__('Baths','ova-brw'); ?>	
						</span>
					</li>
				<?php endif; ?>
				<?php if( !empty($parking) ) : ?>
					<li>
						<i aria-hidden="true" class="icomoon icomoon-parking"></i>
						<span>
						    <?php echo esc_html( $parking ); ?>	
						</span>
					</li>
				<?php endif; ?>
			</ul>

			<p class="room-short-description">
				<?php printf( $short_description ); ?>
			</p>

			<div class="room-container-footer">
				<div class="room-price">
					<span class="text-before">
		            	<?php echo esc_html__('From','ova-brw');?>
		            </span>
					<span class="price-amount">
		            	<?php echo wc_price( $price ); ?>
		            </span>
		            <span class="text-after">
		            	<?php echo esc_html__('/night','ova-brw');?>
		            </span>
		        </div>

				<div class="room-button-wrapper">
					<div class="room-button-view-deals" data-room-id="<?php echo esc_attr( $id ); ?>">
						<a href="<?php echo esc_url( $link ); ?>">
							<?php echo esc_html__( 'View Detail', 'ova-brw' ); ?>
							<i aria-hidden="true" class="ovaicon ovaicon-next-4"></i>
						</a>
					</div>

					<div class="room-button" data-room-id="<?php echo esc_attr( $id ); ?>">
						<?php echo esc_html__( 'Book Now', 'ova-brw' ); ?>
						<i aria-hidden="true" class="ovaicon ovaicon-next-4"></i>
					</div>
			    </div>

			</div>

		</div>
	</div>

	<div class="room-load-more" style="display: none;">
		<svg class="loader" width="50" height="50">
			<circle cx="25" cy="25" r="10" />
			<circle cx="25" cy="25" r="20" />
		</svg>
	</div>
	<div class="booking-room"></div>
</div>