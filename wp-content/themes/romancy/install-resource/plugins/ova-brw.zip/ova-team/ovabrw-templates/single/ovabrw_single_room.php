<?php
if ( ! defined( 'ABSPATH' ) ) exit();

$id 		= get_the_id();
$title 		= get_the_title();
$link 		= get_permalink( $id );
$image_url 	= get_the_post_thumbnail_url( $id, 'romancy_thumbnail' );
$image_id 	= get_post_thumbnail_id();
$image_alt 	= '';

if ( $image_id ) {
	$image_alt 		= get_post_meta( $image_id, '_wp_attachment_image_alt', true );
	if ( empty( $image_alt ) ) {
		$image_alt = get_the_title( $image_id );
	}
}

$price             = get_post_meta( $id, '_regular_price', true );
$bed_number        = get_post_meta( $id, 'ovabrw_bed_number', true );
$area_number       = get_post_meta( $id, 'ovabrw_acreage_number', true );
$area_unit         = get_post_meta( $id, 'ovabrw_acreage_unit', true );
$parking           = get_post_meta( $id, 'ovabrw_parking', true );

?>


<div class="ovabrw-room-content ovabrw-room-content1">
						
	<a class="room-image" href="<?php echo esc_url( $link ); ?>">
		<img src="<?php echo esc_url( $image_url ); ?>" alt="<?php echo esc_attr( $image_alt ); ?>">
		<div class="room-price">
			<span class="text-before">
				<?php echo esc_html__('From','romancy'); ?>
			</span>
        	<?php echo wc_price( $price ); ?><span class="text-after"><?php echo esc_html__('/night','romancy'); ?></span>
        </div>	
	</a>

	<a href="<?php echo esc_url( $link ); ?>">
		<h2 class="room-title">
			<?php echo esc_html( $title ); ?>
		</h2>
	</a>
    
    <?php if( !empty($bed_number) || !empty($area_number) ) { ?>

		<ul class="room-info">

			<?php if( !empty($bed_number) ) { ?>
			    <li class="bed">
			    	<i aria-hidden="true" class="icomoon icomoon-bed"></i>
					<span>
						<?php echo esc_html( $bed_number );?>	
					</span>
				</li>
			<?php } ?>

			<?php if( !empty($area_number) ) { ?>
				<li class="square">
					<i aria-hidden="true" class="icomoon icomoon-measure"></i>
					<span>
						<?php echo esc_html( $area_number );?>
						<?php if ( strcasecmp($area_unit, 'sqm') == 0 ) {
							echo esc_html( $area_unit ) ; }
						else {
							echo esc_html( $area_unit ); ?><sup><?php esc_html_e( '2', 'ova-brw' ); ?></sup>
						<?php } ?>
					</span>
				</li>
			<?php } ?>

		</ul>

	<?php } ?>	

	<a class="ova-room-book-now" href="<?php echo esc_url( $link ); ?>">
		<span class="text-button">
			<?php echo esc_html__('Book now', 'romancy');?>
		</span>
		<i class="ovaicon ovaicon-next" aria-hidden="true"></i>
	</a>

</div>