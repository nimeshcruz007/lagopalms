<?php
namespace ovabrw_product_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly


class ovabrw_product_info extends Widget_Base {


	public function get_name() {		
		return 'ovabrw_product_info';
	}

	public function get_title() {
		return esc_html__( 'Product Information', 'ova-brw' );
	}

	public function get_icon() {
		return 'eicon-product-info';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_demo',
			[
				'label' => esc_html__( 'Demo', 'ova-brw' ),
				'tab' 	=> Controls_Manager::TAB_CONTENT,
			]
		);
			$default_product 	= '';
			$arr_product 		= array();

			$products = ovabrw_get_products_rental();
			if ( !empty( $products ) && is_array( $products ) ) {
				$default_product = $products[0];

				foreach( $products as $product_id ) {
					$arr_product[$product_id] = get_the_title( $product_id );
				}
			} else {
				$arr_product[''] = esc_html__( 'There are no rental products', 'ova-brw' );
			}

			$this->add_control(
				'product_id',
				[
					'label' 	=> esc_html__( 'Choose Product', 'ova-brw' ),
					'type' 		=> \Elementor\Controls_Manager::SELECT,
					'default' 	=> $default_product,
					'options' 	=> $arr_product,
				]
			);

		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_items_info',
			[
				'label' => esc_html__( 'Items', 'ova-brw' ),
			]
		);

		    $this->add_control(
				'number_column',
				[
					'label' => esc_html__('Number Of Columns', 'ova-brw' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'three_column',
					'options' => [
						'two_column'      => esc_html__('2 Columns', 'ova-brw' ),
						'three_column' => esc_html__('3 Columns', 'ova-brw' ),
						'four_column'      => esc_html__('4 Columns', 'ova-brw' ),
					],
				]
			);
            
            $this->add_responsive_control(
				'items_info_gap',
				[
					'label' 		=> esc_html__( 'Grid Gap', 'ova-brw' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px','%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
							'step' => 5,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ovabrw_product_info .room-info' => 'grid-gap: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_responsive_control(
	            'items_info_padding',
	            [
	                'label' 		=> esc_html__( 'Padding', 'ova-brw' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ovabrw_product_info .room-info' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_responsive_control(
	            'items_info_margin',
	            [
	                'label' 		=> esc_html__( 'Margin', 'ova-brw' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ovabrw_product_info .room-info' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

		$this->end_controls_section();

		$this->start_controls_section(
			'section_item_info',
			[
				'label' => esc_html__( 'List Item', 'ova-brw' ),
			]
		);

			$this->add_responsive_control(
		        'item_border_radius',
	            [
	                'label' 		=> esc_html__( 'Border Radius', 'ova-brw' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ovabrw_product_info .room-info li' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
		    );

		    $this->add_responsive_control(
	            'item_info_padding',
	            [
	                'label' 		=> esc_html__( 'Padding', 'ova-brw' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ovabrw_product_info .room-info li' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

	        $this->add_control(
				'item_info_hover_animation',
				[
					'label' => esc_html__( 'Hover Animation', 'ova-brw' ),
					'type' => \Elementor\Controls_Manager::HOVER_ANIMATION,
				]
			);

			$this->start_controls_tabs(
				'style_tabs'
			);

				$this->start_controls_tab(
					'style_normal_tab',
					[
						'label' => esc_html__( 'Normal', 'ova-brw' ),
					]
				);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'box_shadow',
							'label' => esc_html__( 'Box Shadow', 'ova-brw' ),
							'selector' => '{{WRAPPER}} .ovabrw_product_info .room-info li',
						]
					);

					$this->add_control(
						'item_bgcolor',
						[
							'label' 	=> esc_html__( 'Background Color', 'ova-brw' ),
							'type' 		=> Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ovabrw_product_info .room-info li' => 'background-color: {{VALUE}};',
							],
						]
					);

				$this->end_controls_tab();

				$this->start_controls_tab(
					'style_hover_tab',
					[
						'label' => esc_html__( 'Hover', 'ova-brw' ),
					]
				);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'box_shadow_hover',
							'label' => esc_html__( 'Box Shadow', 'ova-brw' ),
							'selector' => '{{WRAPPER}} .ovabrw_product_info .room-info li:hover',
						]
					);

					$this->add_control(
						'item_bgcolor_hover',
						[
							'label' 	=> esc_html__( 'Background Color', 'ova-brw' ),
							'type' 		=> Controls_Manager::COLOR,
							'selectors' => [
								'{{WRAPPER}} .ovabrw_product_info .room-info li:hover' => 'background-color: {{VALUE}};',
							],
						]
					);

				$this->end_controls_tab();

			$this->end_controls_tabs();

		$this->end_controls_section();

		/* Begin title Style */
		$this->start_controls_section(
            'title_style',
            [
                'label' => esc_html__( 'Title', 'ova-brw' ),
            ]
        );

            $this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' 		=> 'title_typography',
					'selector' 	=> '{{WRAPPER}} .ovabrw_product_info .room-info li span',
				]
			);

			$this->add_control(
				'title_color',
				[
					'label' 	=> esc_html__( 'Color', 'ova-brw' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ovabrw_product_info .room-info li span' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'title_color_hover',
				[
					'label' 	=> esc_html__( 'Color Hover', 'ova-brw' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ovabrw_product_info .room-info li:hover span' => 'color: {{VALUE}};',
					],
				]
			);

        $this->end_controls_section();
		/* End title style */

		/* Begin icon Style */
		$this->start_controls_section(
            'icon_style',
            [
                'label' => esc_html__( 'Icon', 'ova-brw' ),
            ]
        );
            
			$this->add_responsive_control(
				'size_icon',
				[
					'label' 		=> esc_html__( 'Size', 'ova-brw' ),
					'type' 			=> Controls_Manager::SLIDER,
					'size_units' 	=> [ 'px'],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 70,
							'step' => 1,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ovabrw_product_info .room-info li i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_control(
				'icon_color',
				[
					'label' 	=> esc_html__( 'Color', 'ova-brw' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ovabrw_product_info .room-info li i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_control(
				'icon_color_hover',
				[
					'label' 	=> esc_html__( 'Color Hover', 'ova-brw' ),
					'type' 		=> Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .ovabrw_product_info .room-info li:hover i' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_responsive_control(
	            'icon_margin',
	            [
	                'label' 		=> esc_html__( 'Margin', 'ova-brw' ),
	                'type' 			=> Controls_Manager::DIMENSIONS,
	                'size_units' 	=> [ 'px', '%', 'em' ],
	                'selectors' 	=> [
	                    '{{WRAPPER}} .ovabrw_product_info .room-info li i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
	                ],
	            ]
	        );

        $this->end_controls_section();
		/* End icon style */
		
	}

	protected function render() {

		$settings 	= $this->get_settings();

		$column     		 = $settings['number_column'];
		$container_animation = $settings['item_info_hover_animation'];

		// Get Product
		$product  = wc_get_product();

		if ( empty( $product ) ) {
			$product_id = $settings['product_id'];
			$product 	= wc_get_product( $product_id );
		}

    	if ( !$product || !$product->is_type('ovabrw_car_rental') ) {
			?>
			<div class="ovabrw_elementor_no_product">
				<span><?php echo $this->get_title(); ?></span>
			</div>
			<?php
			return;
		}

		$id = $product->get_id();

		// Get information
		$parking           = get_post_meta( $id, 'ovabrw_parking', true );
		$children_number   = get_post_meta( $id, 'ovabrw_children_number', true );
		$adult_number      = get_post_meta( $id, 'ovabrw_adult_number', true );
		$area_number       = get_post_meta( $id, 'ovabrw_acreage_number', true );
		$area_unit         = get_post_meta( $id, 'ovabrw_acreage_unit', true );
		$bed_number        = get_post_meta( $id, 'ovabrw_bed_number', true );
		$bath_number       = get_post_meta( $id, 'ovabrw_bath_number', true );

		?>

		<div class="ovabrw_product_info">
              <ul class="room-info <?php echo esc_attr($column); ?>">
              	<li class="elementor-animation-<?php echo esc_attr( $container_animation );?>">
					<i class="icomoon-man"></i>
					<span>
						<?php if ( $adult_number == 1 ): ?>
					    	<?php echo esc_html( $adult_number ) . ' ' . esc_html__('Adult','ova-brw'); ?>
					    <?php else: ?>
					    	<?php echo esc_html( $adult_number ) . ' ' . esc_html__('Adults','ova-brw'); ?>
					    <?php endif; ?>
					</span>
				</li>
              	<li class="elementor-animation-<?php echo esc_attr( $container_animation );?>">
					<i class="icomoon-daughter"></i>
					<span>
						<?php if ( $children_number == 1 ): ?>
					    	<?php echo esc_html( $children_number ) . ' ' . esc_html__('Child','ova-brw'); ?>	
					    <?php else: ?>
					    	<?php echo esc_html( $children_number ) . ' ' . esc_html__('Children','ova-brw'); ?>	
					    <?php endif; ?>
					</span>
				</li>
				<li class="elementor-animation-<?php echo esc_attr( $container_animation );?>">
					<i class="icomoon-measure"></i>
					<span> 
						<?php echo esc_html( $area_number );?>	
						<?php echo esc_html( $area_unit );?><sup>2</sup>
					</span>
				</li>
              	<li class="elementor-animation-<?php echo esc_attr( $container_animation );?>">
					<i class="icomoon-parking"></i>
					<span> 
						<?php echo esc_html( $parking ); ?>	
					</span>
				</li>
				<li class="elementor-animation-<?php echo esc_attr( $container_animation );?>">
					<i class="icomoon-bed"></i>
					<span>
						<?php if ( $bed_number == 1 ): ?>
					    	<?php echo esc_html( $bed_number ) . ' ' . esc_html__('Bed','ova-brw'); ?>	
					    <?php else: ?>
					    	<?php echo esc_html( $bed_number ) . ' ' . esc_html__('Beds','ova-brw'); ?>
					    <?php endif; ?>
					</span>
				</li>
				<li class="elementor-animation-<?php echo esc_attr( $container_animation );?>">
					<i class="icomoon-bathtub"></i>
					<span>
					    <?php if ( $bath_number == 1 ): ?>
					    	<?php echo esc_html( $bath_number ) . ' ' . esc_html__('Bath','ova-brw'); ?>	
					    <?php else: ?>
					    	<?php echo esc_html( $bath_number ) . ' ' . esc_html__('Baths','ova-brw'); ?>
					    <?php endif; ?>	
					</span>
				</li>
			</ul>
		</div>

		<?php
	}

	
}