<?php
namespace ovabrw_product_elementor\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Border;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class ovabrw_product_images extends Widget_Base {

	public function get_name() {		
		return 'ovabrw_product_images';
	}

	public function get_title() {
		return esc_html__( 'Product Images', 'ova-brw' );
	}

	public function get_icon() {
		return 'eicon-product-images';
	}

	public function get_categories() {
		return [ 'ovatheme' ];
	}

	public function get_script_depends() {
		// Carousel
		wp_enqueue_script('brw-owl-carousel', OVABRW_PLUGIN_URI.'assets/libs/carousel/owl.carousel.min.js', array('jquery'),null,true);
		wp_enqueue_style('brw-owl-carousel', OVABRW_PLUGIN_URI.'assets/libs/carousel/assets/owl.carousel.min.css', array(), null);
		return [ 'script-elementor' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_demo',
			[
				'label' => esc_html__( 'Demo', 'ova-brw' ),
			]
		);
			$default_product 	= '';
			$arr_product 		= array();

			$products = ovabrw_get_products_rental();
			if ( !empty( $products ) && is_array( $products ) ) {
				$default_product = $products[0];

				foreach( $products as $product_id ) {
					$arr_product[$product_id] = get_the_title( $product_id );
				}
			} else {
				$arr_product[''] = esc_html__( 'There are no rental products', 'ova-brw' );
			}

			$this->add_control(
				'product_id',
				[
					'label' 	=> esc_html__( 'Choose Product', 'ova-brw' ),
					'type' 		=> \Elementor\Controls_Manager::SELECT,
					'default' 	=> $default_product,
					'options' 	=> $arr_product,
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_additional_options',
			[
				'label' => esc_html__( 'Additional Options', 'ova-brw' ),
			]
		);

			$this->add_control(
				'margin_items',
				[
					'label'   => esc_html__( 'Margin Items', 'ova-brw' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 9,
				]
			);

			$this->add_control(
				'item_number',
				[
					'label'       => esc_html__( 'Item Number', 'ova-brw' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => esc_html__( 'Number Item', 'ova-brw' ),
					'default'     => 4,
				]
			);

			$this->add_control(
				'slides_to_scroll',
				[
					'label'       => esc_html__( 'Slides to Scroll', 'ova-brw' ),
					'type'        => Controls_Manager::NUMBER,
					'description' => esc_html__( 'Set how many slides are scrolled per swipe.', 'ova-brw' ),
					'default'     => 1,
				]
			);

			$this->add_control(
				'pause_on_hover',
				[
					'label'   => esc_html__( 'Pause on Hover', 'ova-brw' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-brw' ),
						'no'  => esc_html__( 'No', 'ova-brw' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'infinite',
				[
					'label'   => esc_html__( 'Infinite Loop', 'ova-brw' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-brw' ),
						'no'  => esc_html__( 'No', 'ova-brw' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay',
				[
					'label'   => esc_html__( 'Autoplay', 'ova-brw' ),
					'type'    => Controls_Manager::SWITCHER,
					'default' => 'yes',
					'options' => [
						'yes' => esc_html__( 'Yes', 'ova-brw' ),
						'no'  => esc_html__( 'No', 'ova-brw' ),
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'autoplay_speed',
				[
					'label'     => esc_html__( 'Autoplay Speed', 'ova-brw' ),
					'type'      => Controls_Manager::NUMBER,
					'default'   => 3000,
					'step'      => 500,
					'condition' => [
						'autoplay' => 'yes',
					],
					'frontend_available' => true,
				]
			);

			$this->add_control(
				'smartspeed',
				[
					'label'   => esc_html__( 'Smart Speed', 'ova-brw' ),
					'type'    => Controls_Manager::NUMBER,
					'default' => 500,
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_product_featured_img',
			[
				'label' => esc_html__( 'Featured Image', 'ova-brw' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'custom_size',
				[
					'label' 	=> esc_html__( 'Custom Size', 'ova-brw' ),
					'type' 		=> \Elementor\Controls_Manager::SWITCHER,
					'label_on' 	=> esc_html__( 'Yes', 'ova-brw' ),
					'label_off' => esc_html__( 'No', 'ova-brw' ),
					'default' 	=> 'no',
				]
			);

			$this->add_control(
				'featured_img_width',
				[
					'label' => esc_html__( 'Width', 'ova-brw' ),
					'type' 	=> \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'default' => [
						'unit' => '%',
						'size' => 100,
					],
					'selectors' => [
						'{{WRAPPER}} .ova-product-img .featured-img img' => 'width: {{SIZE}}{{UNIT}};',
					],
					'condition' => [
						'custom_size' => 'yes',
					],
				]
			);

			$this->add_control(
				'featured_img_height',
				[
					'label' => esc_html__( 'Height', 'ova-brw' ),
					'type' 	=> \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .ova-product-img .featured-img img' => 'height: {{SIZE}}{{UNIT}};',
					],
					'condition' => [
						'custom_size' => 'yes',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'featured_img_border',
					'label' => esc_html__( 'Border', 'ova-brw' ),
					'selector' => '{{WRAPPER}} .ova-product-img .featured-img',
				]
			);

			$this->add_responsive_control(
				'featured_img_border_radius',
				[
					'label' 	 => esc_html__( 'Border Radius', 'ova-brw' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-product-img .featured-img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
					],
				]
			);

			$this->add_responsive_control(
				'featured_img_margin',
				[
					'label' 	 => esc_html__( 'Margin', 'ova-brw' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-product-img .featured-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_product_gallery_img',
			[
				'label' => esc_html__( 'Gallery Image', 'ova-brw' ),
				'tab' 	=> Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'gallery_img_border',
					'label' => esc_html__( 'Border', 'ova-brw' ),
					'selector' => '{{WRAPPER}} .ova-product-img .gallery .product-gallery .gallery-item',
				]
			);

			$this->add_responsive_control(
				'gallery_img_border_radius',
				[
					'label' 	 => esc_html__( 'Border Radius', 'ova-brw' ),
					'type' 		 => Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', '%' ],
					'selectors'  => [
						'{{WRAPPER}} .ova-product-img .gallery .product-gallery .gallery-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}',
					],
				]
			);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings();

		$product  = wc_get_product();
		if ( empty( $product ) ) {
			$product_id = $settings['product_id'];
			$product 	= wc_get_product( $product_id );
		}

    	if ( !$product || !$product->is_type('ovabrw_car_rental') ) {
			?>
			<div class="ovabrw_elementor_no_product">
				<span><?php echo $this->get_title(); ?></span>
			</div>
			<?php
			return;
		}

		$img_url 	= $img_alt = '';
		$img_id 	= $product->get_image_id();
		$data_gallery = array();

		if ( $img_id ) {
			$img_url = wp_get_attachment_url( $img_id );
			$img_alt = get_post_meta( $img_id, '_wp_attachment_image_alt', true );

			if ( ! $img_alt ) {
				$img_alt = get_the_title( $img_id );
			}
		}

		$gallery_ids = $product->get_gallery_image_ids();

		// Carousel option
		$carousel_options['items']              = $settings['item_number'];
		$carousel_options['slideBy']            = $settings['slides_to_scroll'];
		$carousel_options['margin']             = $settings['margin_items'];
		$carousel_options['autoplayHoverPause'] = $settings['pause_on_hover'] === 'yes' ? true : false;
		$carousel_options['loop']               = $settings['infinite'] === 'yes' ? true : false;
		$carousel_options['autoplay']           = $settings['autoplay'] === 'yes' ? true : false;
		$carousel_options['autoplayTimeout']    = $settings['autoplay_speed'];
		$carousel_options['smartSpeed']         = $settings['smartspeed'];
		$carousel_options['rtl']				= is_rtl() ? true: false;

		?>
		<?php if ( $img_url ): 
			array_push( $data_gallery , array(
				'src' 		=> $img_url,
				'caption' 	=> $img_alt,
				'thumb' 	=> $img_url,
			));
		?>
			<div class="ova-product-img">
				<div class="featured-img">
					<a class="gallery-fancybox" data-index='0' href="javascript:;">
	  					<img src="<?php echo esc_url( $img_url ); ?>" alt="<?php echo esc_attr( $img_alt ); ?>">
	  				</a>
				</div>
				<?php if ( !empty( $gallery_ids ) && is_array( $gallery_ids ) ): ?>
				<div class="gallery">
					<div class="product-gallery owl-carousel owl-theme" 
						data-options="<?php echo esc_attr( json_encode( $carousel_options ) ); ?>">
						<?php foreach( $gallery_ids as $k => $gallery_id ): 
							$gallery_url = wp_get_attachment_url( $gallery_id );
							$gallery_alt = get_post_meta( $gallery_id, '_wp_attachment_image_alt', true );

							if ( !$gallery_alt ) {
								$gallery_alt = get_the_title( $gallery_id );
							}

							array_push( $data_gallery , array(
								'src' 		=> $gallery_url,
								'caption' 	=> $gallery_alt,
								'thumb' 	=> $gallery_url,
							));
						?>
							<div class="gallery-item">
								<a class="gallery-fancybox" data-index="<?php esc_attr_e( $k+1 ); ?>" href="javascript:;">
				  					<img src="<?php echo esc_url( $gallery_url ); ?>" alt="<?php echo esc_attr( $gallery_alt ); ?>">
				  				</a>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
				<?php endif; ?>
				<div class="data-gallery" data-gallery="<?php echo esc_attr( json_encode( $data_gallery ) ); ?>"></div>
			</div>
		<?php endif;
	}
}