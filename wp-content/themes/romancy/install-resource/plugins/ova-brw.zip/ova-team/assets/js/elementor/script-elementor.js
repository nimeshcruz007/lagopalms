(function($){
	"use strict";

	$(window).on('elementor/frontend/init', function () {

		function gueststotal( that, cal ) {
	    	var guests_button = that.closest('.guests-button');
			var input 	= guests_button.find('input[type="text"]');
			var value 	= input.val();
			var min 	= input.attr('min');
			var max 	= input.attr('max');

			if ( cal == 'sub' && parseInt(value) > parseInt(min) ) {
				input.val(parseInt(value) - 1);
			}

			if ( cal == 'sum' && parseInt(value) < parseInt(max) ) {
				input.val(parseInt(value) + 1);
			}

			var guestspicker_control = that.closest('.guestspicker-control');
			var adults = guestspicker_control.find('.ovabrw_adults').val();
			var children = guestspicker_control.find('.ovabrw_childrens').val();
			var gueststotal = guestspicker_control.find('.gueststotal');
			if ( gueststotal ) {
				gueststotal.text( parseInt(adults) + parseInt(children) );
			}
	    }

	    function guestspicker( that ) {
			var guestspicker = that.find('.ovabrw-guestspicker');
			var guestspicker_control = that.find('.guestspicker-control');

			guestspicker.on('click', function() {
				$(this).closest('.guestspicker-control').toggleClass('active');
			});

			$(window).click( function(e) {
				var guestspicker_content = $('.ovabrw-guestspicker-content');
        		if ( !guestspicker.is(e.target) && guestspicker.has(e.target).length === 0 && !guestspicker_content.is(e.target) && guestspicker_content.has(e.target).length === 0 ) {
        			guestspicker_control.removeClass('active');
        		}
			});
	    }

		// Product images
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_product_images.default', function(){
			$(".ova-product-img .product-gallery").each(function(){
		        var owlsl = $(this) ;
		        var owlsl_ops = owlsl.data('options') ? owlsl.data('options') : {};

		        var responsive = {
		            0:{
		                items: 2,
		          		slideBy: 1,
		            },
		            768:{
		              	items: 3,
		              	slideBy: 1,
		            },
		            1024: {
		            	items: owlsl_ops.items,
		              	slideBy: owlsl_ops.slideBy,
		            }
		        };
		        
		        owlsl.owlCarousel({
					items: owlsl_ops.items,
					slideBy: owlsl_ops.slideBy,
					margin: owlsl_ops.margin,
					autoplayHoverPause: owlsl_ops.autoplayHoverPause,
					loop: owlsl_ops.loop,
					autoplay: owlsl_ops.autoplay,
					autoplayTimeout: owlsl_ops.autoplayTimeout,
					smartSpeed: owlsl_ops.smartSpeed,
					rtl: owlsl_ops.rtl,
					nav: false,
		          	dots: false,
					responsive: responsive,
		        });

		        $('.ova-product-img .gallery-fancybox').on('click', function() {
					var that = $(this);
					var index = that.data('index');
					var gallery_data = that.closest('.ova-product-img').find('.data-gallery').data('gallery');

					Fancybox.show(gallery_data, {
		            	Image: {
						    Panzoom: {
						      	zoomFriction: 0.7,
						      	maxScale: function () {
						        	return 3;
						      	},
						    },
					  	},
					  	startIndex: index,
					});
				});
			});
		});
        
        // Product calendar
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_product_calendar.default', function(){	
          
		});
        
        // Product Related
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_product_related.default', function(){

			$(".elementor-ralated-slide .elementor-ralated").each(function(){
		        var owlsl = $(this) ;
		        var owlsl_ops = owlsl.data('options') ? owlsl.data('options') : {};

		        var responsive_value = {
		            0:{
		              items:1,
		            },
		            769:{
		              items:2
		            },
		            1025:{
		              items:owlsl_ops.items
		            }
		        };
		        
		        owlsl.owlCarousel({
		          autoWidth: owlsl_ops.autoWidth,
		          margin: owlsl_ops.margin,
		          items: owlsl_ops.items,
		          loop: owlsl_ops.loop,
		          autoplay: owlsl_ops.autoplay,
		          autoplayTimeout: owlsl_ops.autoplayTimeout,
		          center: owlsl_ops.center,
		          nav: owlsl_ops.nav,
		          dots: owlsl_ops.dots,
		          thumbs: owlsl_ops.thumbs,
		          autoplayHoverPause: owlsl_ops.autoplayHoverPause,
		          slideBy: owlsl_ops.slideBy,
		          smartSpeed: owlsl_ops.smartSpeed,
		          rtl: owlsl_ops.rtl,
		          responsive: responsive_value,
		        });

		      	/* Fixed WCAG */
				owlsl.find(".owl-dots button").attr("title", "Dots");

		      });
		});

		/* Search */
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_search.default', function(){

			$(".ovabrw-search .ovabrw-search-form").each(function(){

				var that = $(this);
                
				guestspicker(that);

				var minus = that.find('.minus');
				minus.on('click', function() {
					gueststotal($(this), 'sub');
				});

				var plus = that.find('.plus');
				plus.on('click', function() {
					gueststotal($(this), 'sum');
				});

		    });
		});

		/* Search 2 */
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_search2.default', function(){

			$(".ovabrw-search2 .ovabrw-search-form").each(function(){
                
                var that = $(this);

				guestspicker(that);

				var minus = that.find('.minus');
				minus.on('click', function() {
					gueststotal($(this), 'sub');
				});

				var plus = that.find('.plus');
				plus.on('click', function() {
					gueststotal($(this), 'sum');
				});

		    });
		 
		});

		/* Search Ajax */
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_search_ajax.default', function(){
			$(".ovabrw-search-ajax .wrap-search-ajax").each(function(){
				var that = $(this);

				guestspicker(that);

				var minus = that.find('.minus');
				minus.on('click', function() {
					gueststotal($(this), 'sub');
				});

				var plus = that.find('.plus');
				plus.on('click', function() {
					gueststotal($(this), 'sum');
				});

		    });

		});
        
        /* Booking form */
		elementorFrontend.hooks.addAction('frontend/element_ready/ovabrw_product_booking_form.default', function(){

			// Booking Tabs
			$('.forms-booking-tab').each( function() {
				var that = $(this);

				var item    = that.find('.tabs .item');
		        var booking = that.find('.romancy-booking');

				item.on( 'click', function() {
					if ( ! $(this).hasClass('active') ) {
						item.removeClass('active');
						$(this).addClass('active');
				        booking.hide();
				        var form = $(this).data('form');
				        that.find('.'+$(this).data('form')).show();
					}
				});
			});

		});

   });

})(jQuery);
